import { pgTable, uuid, text, timestamp, boolean, jsonb, integer, doublePrecision } from "drizzle-orm/pg-core";

/* ============================== 1–7 · CORE ============================== */

export const projects = pgTable("kdj_projects", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  color: text("color").notNull().default("#8b5cf6"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const conversations = pgTable("kdj_conversations", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull().default("New chat"),
  model: text("model").notNull().default("kdj-4o"),
  projectId: uuid("project_id"),
  pinned: boolean("pinned").notNull().default(false),
  archived: boolean("archived").notNull().default(false),
  gptId: uuid("gpt_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const messages = pgTable("kdj_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  conversationId: uuid("conversation_id").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  model: text("model"),
  attachments: jsonb("attachments").$type<{ name: string; type: string; size: number; preview?: string; text?: string }[]>(),
  imageUrl: text("image_url"),
  reasoning: text("reasoning"),
  sources: jsonb("sources").$type<{ title: string; url: string; snippet: string }[]>(),
  feedback: text("feedback"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const customGpts = pgTable("kdj_custom_gpts", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  instructions: text("instructions").notNull().default(""),
  emoji: text("emoji").notNull().default("🤖"),
  tools: jsonb("tools").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const memories = pgTable("kdj_memories", {
  id: uuid("id").defaultRandom().primaryKey(),
  fact: text("fact").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const generatedImages = pgTable("kdj_generated_images", {
  id: uuid("id").defaultRandom().primaryKey(),
  prompt: text("prompt").notNull(),
  url: text("url").notNull(),
  style: text("style").notNull().default("vivid"),
  conversationId: uuid("conversation_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sharedChats = pgTable("kdj_shared_chats", {
  id: uuid("id").defaultRandom().primaryKey(),
  conversationId: uuid("conversation_id").notNull(),
  title: text("title").notNull().default("Shared chat"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ======================= 8–17 · USERS & ACCESS ======================= */

export const users = pgTable("kdj_users", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: text("email").notNull(),
  name: text("name").notNull().default("User"),
  avatarUrl: text("avatar_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const userProfiles = pgTable("kdj_user_profiles", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  bio: text("bio"),
  locale: text("locale").notNull().default("en-US"),
  theme: text("theme").notNull().default("dark"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sessions = pgTable("kdj_sessions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  token: text("token"),
  ip: text("ip"),
  device: text("device"),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const apiKeys = pgTable("kdj_api_keys", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  name: text("name").notNull().default("Default"),
  keyHash: text("key_hash"),
  scopes: jsonb("scopes").$type<string[]>().notNull().default([]),
  lastUsedAt: timestamp("last_used_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const planTiers = pgTable("kdj_plan_tiers", {
  id: uuid("id").defaultRandom().primaryKey(),
  slug: text("slug").notNull(),
  name: text("name").notNull(),
  priceMonthly: doublePrecision("price_monthly").notNull().default(0),
  features: jsonb("features").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const planSubscriptions = pgTable("kdj_plan_subscriptions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  tierId: uuid("tier_id"),
  status: text("status").notNull().default("active"),
  renewsAt: timestamp("renews_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const userSettings = pgTable("kdj_user_settings", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  key: text("key").notNull(),
  value: jsonb("value"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const userStats = pgTable("kdj_user_stats", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  messagesSent: integer("messages_sent").notNull().default(0),
  imagesGenerated: integer("images_generated").notNull().default(0),
  tokensUsed: integer("tokens_used").notNull().default(0),
  streakDays: integer("streak_days").notNull().default(0),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const activityLog = pgTable("kdj_activity_log", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  action: text("action").notNull(),
  meta: jsonb("meta"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const notifications = pgTable("kdj_notifications", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  title: text("title").notNull(),
  body: text("body"),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ===================== 18–25 · PROJECTS & FOLDERS ==================== */

export const projectMembers = pgTable("kdj_project_members", {
  id: uuid("id").defaultRandom().primaryKey(),
  projectId: uuid("project_id"),
  userId: uuid("user_id"),
  role: text("role").notNull().default("member"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const projectInstructions = pgTable("kdj_project_instructions", {
  id: uuid("id").defaultRandom().primaryKey(),
  projectId: uuid("project_id"),
  instructions: text("instructions").notNull().default(""),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const projectFiles = pgTable("kdj_project_files", {
  id: uuid("id").defaultRandom().primaryKey(),
  projectId: uuid("project_id"),
  name: text("name").notNull(),
  mime: text("mime").notNull().default("text/plain"),
  size: integer("size").notNull().default(0),
  content: text("content"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const projectActivity = pgTable("kdj_project_activity", {
  id: uuid("id").defaultRandom().primaryKey(),
  projectId: uuid("project_id"),
  action: text("action").notNull(),
  detail: text("detail"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const folders = pgTable("kdj_folders", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  name: text("name").notNull(),
  color: text("color").notNull().default("#8b5cf6"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const folderChats = pgTable("kdj_folder_chats", {
  id: uuid("id").defaultRandom().primaryKey(),
  folderId: uuid("folder_id"),
  conversationId: uuid("conversation_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const tags = pgTable("kdj_tags", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  name: text("name").notNull(),
  color: text("color").notNull().default("#22d3ee"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const chatTags = pgTable("kdj_chat_tags", {
  id: uuid("id").defaultRandom().primaryKey(),
  conversationId: uuid("conversation_id"),
  tagId: uuid("tag_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ================== 26–34 · MESSAGES & FEEDBACK ===================== */

export const messageBranches = pgTable("kdj_message_branches", {
  id: uuid("id").defaultRandom().primaryKey(),
  conversationId: uuid("conversation_id"),
  parentMessageId: uuid("parent_message_id"),
  activeIndex: integer("active_index").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messageEdits = pgTable("kdj_message_edits", {
  id: uuid("id").defaultRandom().primaryKey(),
  messageId: uuid("message_id"),
  previousContent: text("previous_content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messageRatings = pgTable("kdj_message_ratings", {
  id: uuid("id").defaultRandom().primaryKey(),
  messageId: uuid("message_id"),
  rating: text("rating").notNull(),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messageReports = pgTable("kdj_message_reports", {
  id: uuid("id").defaultRandom().primaryKey(),
  messageId: uuid("message_id"),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messageRegenerations = pgTable("kdj_message_regenerations", {
  id: uuid("id").defaultRandom().primaryKey(),
  messageId: uuid("message_id"),
  variantContent: text("variant_content").notNull(),
  model: text("model"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messageMentions = pgTable("kdj_message_mentions", {
  id: uuid("id").defaultRandom().primaryKey(),
  messageId: uuid("message_id"),
  mentionedUserId: uuid("mentioned_user_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const embeddings = pgTable("kdj_embeddings", {
  id: uuid("id").defaultRandom().primaryKey(),
  sourceTable: text("source_table").notNull(),
  sourceId: uuid("source_id"),
  chunk: text("chunk").notNull(),
  vector: jsonb("vector").$type<number[]>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reactions = pgTable("kdj_reactions", {
  id: uuid("id").defaultRandom().primaryKey(),
  messageId: uuid("message_id"),
  userId: uuid("user_id"),
  emoji: text("emoji").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const tempChats = pgTable("kdj_temp_chats", {
  id: uuid("id").defaultRandom().primaryKey(),
  content: jsonb("content"),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ==================== 35–42 · CUSTOM GPT BUILDER ==================== */

export const gptBuilders = pgTable("kdj_gpt_builders", {
  id: uuid("id").defaultRandom().primaryKey(),
  gptId: uuid("gpt_id"),
  ownerUserId: uuid("owner_user_id"),
  status: text("status").notNull().default("draft"),
  visibility: text("visibility").notNull().default("private"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const gptKnowledgeFiles = pgTable("kdj_gpt_knowledge_files", {
  id: uuid("id").defaultRandom().primaryKey(),
  gptId: uuid("gpt_id"),
  name: text("name").notNull(),
  content: text("content"),
  size: integer("size").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const gptActions = pgTable("kdj_gpt_actions", {
  id: uuid("id").defaultRandom().primaryKey(),
  gptId: uuid("gpt_id"),
  name: text("name").notNull(),
  schema: jsonb("schema"),
  endpoint: text("endpoint"),
  authType: text("auth_type").notNull().default("none"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const gptStarters = pgTable("kdj_gpt_starters", {
  id: uuid("id").defaultRandom().primaryKey(),
  gptId: uuid("gpt_id"),
  label: text("label").notNull(),
  prompt: text("prompt").notNull(),
  sort: integer("sort").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const gptCapabilities = pgTable("kdj_gpt_capabilities", {
  id: uuid("id").defaultRandom().primaryKey(),
  gptId: uuid("gpt_id"),
  webBrowsing: boolean("web_browsing").notNull().default(true),
  imageGen: boolean("image_gen").notNull().default(true),
  codeInterpreter: boolean("code_interpreter").notNull().default(true),
  canvas: boolean("canvas").notNull().default(true),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const gptReviews = pgTable("kdj_gpt_reviews", {
  id: uuid("id").defaultRandom().primaryKey(),
  gptId: uuid("gpt_id"),
  userId: uuid("user_id"),
  stars: integer("stars").notNull().default(5),
  comment: text("comment"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const gptInstalls = pgTable("kdj_gpt_installs", {
  id: uuid("id").defaultRandom().primaryKey(),
  gptId: uuid("gpt_id"),
  userId: uuid("user_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const gptVersions = pgTable("kdj_gpt_versions", {
  id: uuid("id").defaultRandom().primaryKey(),
  gptId: uuid("gpt_id"),
  version: integer("version").notNull().default(1),
  snapshot: jsonb("snapshot"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ===================== 43–50 · IMAGES & FILES ======================= */

export const imageStyles = pgTable("kdj_image_styles", {
  id: uuid("id").defaultRandom().primaryKey(),
  slug: text("slug").notNull(),
  name: text("name").notNull(),
  suffix: text("suffix").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const imageCollections = pgTable("kdj_image_collections", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  name: text("name").notNull(),
  imageIds: jsonb("image_ids").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const imageVariations = pgTable("kdj_image_variations", {
  id: uuid("id").defaultRandom().primaryKey(),
  parentImageId: uuid("parent_image_id"),
  url: text("url").notNull(),
  prompt: text("prompt").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const uploads = pgTable("kdj_uploads", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  conversationId: uuid("conversation_id"),
  name: text("name").notNull(),
  mime: text("mime").notNull(),
  size: integer("size").notNull().default(0),
  storageUrl: text("storage_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const fileChunks = pgTable("kdj_file_chunks", {
  id: uuid("id").defaultRandom().primaryKey(),
  uploadId: uuid("upload_id"),
  chunkIndex: integer("chunk_index").notNull().default(0),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const fileShares = pgTable("kdj_file_shares", {
  id: uuid("id").defaultRandom().primaryKey(),
  uploadId: uuid("upload_id"),
  publicId: text("public_id"),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const attachmentsRegistry = pgTable("kdj_attachments_registry", {
  id: uuid("id").defaultRandom().primaryKey(),
  messageId: uuid("message_id"),
  uploadId: uuid("upload_id"),
  kind: text("kind").notNull().default("file"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const trash = pgTable("kdj_trash", {
  id: uuid("id").defaultRandom().primaryKey(),
  itemType: text("item_type").notNull(),
  itemId: uuid("item_id"),
  snapshot: jsonb("snapshot"),
  deletedAt: timestamp("deleted_at").defaultNow().notNull(),
});

/* ======================== 51–56 · VOICE ============================== */

export const voiceSessions = pgTable("kdj_voice_sessions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  conversationId: uuid("conversation_id"),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  endedAt: timestamp("ended_at"),
  durationSeconds: integer("duration_seconds").notNull().default(0),
});

export const voiceSettings = pgTable("kdj_voice_settings", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  voiceName: text("voice_name").notNull().default("KDJ-Nova"),
  speed: doublePrecision("speed").notNull().default(1),
  language: text("language").notNull().default("en-US"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const audioMessages = pgTable("kdj_audio_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  messageId: uuid("message_id"),
  url: text("url"),
  transcript: text("transcript"),
  durationSeconds: integer("duration_seconds").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const ttsCache = pgTable("kdj_tts_cache", {
  id: uuid("id").defaultRandom().primaryKey(),
  textHash: text("text_hash").notNull(),
  voiceName: text("voice_name").notNull().default("KDJ-Nova"),
  url: text("url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sttTranscripts = pgTable("kdj_stt_transcripts", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  transcript: text("transcript").notNull(),
  confidence: doublePrecision("confidence"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const voiceClones = pgTable("kdj_voice_clones", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  name: text("name").notNull(),
  sampleUrl: text("sample_url"),
  status: text("status").notNull().default("processing"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ===================== 57–62 · CANVAS & CODE ======================== */

export const canvasDocuments = pgTable("kdj_canvas_documents", {
  id: uuid("id").defaultRandom().primaryKey(),
  conversationId: uuid("conversation_id"),
  title: text("title").notNull().default("Untitled canvas"),
  language: text("language").notNull().default("html"),
  content: text("content").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const canvasVersions = pgTable("kdj_canvas_versions", {
  id: uuid("id").defaultRandom().primaryKey(),
  canvasId: uuid("canvas_id"),
  content: text("content").notNull(),
  version: integer("version").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const canvasCollaborators = pgTable("kdj_canvas_collaborators", {
  id: uuid("id").defaultRandom().primaryKey(),
  canvasId: uuid("canvas_id"),
  userId: uuid("user_id"),
  role: text("role").notNull().default("editor"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const codeSnippets = pgTable("kdj_code_snippets", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  title: text("title").notNull(),
  language: text("language").notNull().default("javascript"),
  code: text("code").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const codeRuns = pgTable("kdj_code_runs", {
  id: uuid("id").defaultRandom().primaryKey(),
  snippetId: uuid("snippet_id"),
  stdout: text("stdout"),
  stderr: text("stderr"),
  exitCode: integer("exit_code"),
  durationMs: integer("duration_ms"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const notebooks = pgTable("kdj_notebooks", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  title: text("title").notNull().default("Untitled notebook"),
  cells: jsonb("cells").$type<{ type: string; content: string }[]>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ===================== 63–70 · WEB & RESEARCH ======================= */

export const webSearches = pgTable("kdj_web_searches", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  query: text("query").notNull(),
  resultCount: integer("result_count").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const webResults = pgTable("kdj_web_results", {
  id: uuid("id").defaultRandom().primaryKey(),
  searchId: uuid("search_id"),
  title: text("title").notNull(),
  url: text("url").notNull(),
  snippet: text("snippet"),
  rank: integer("rank").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const savedSources = pgTable("kdj_saved_sources", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  title: text("title").notNull(),
  url: text("url").notNull(),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const citationsLibrary = pgTable("kdj_citations_library", {
  id: uuid("id").defaultRandom().primaryKey(),
  messageId: uuid("message_id"),
  title: text("title").notNull(),
  url: text("url").notNull(),
  style: text("style").notNull().default("apa"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const scheduledTasks = pgTable("kdj_scheduled_tasks", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  name: text("name").notNull(),
  prompt: text("prompt").notNull(),
  cron: text("cron").notNull().default("0 9 * * *"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const taskRuns = pgTable("kdj_task_runs", {
  id: uuid("id").defaultRandom().primaryKey(),
  taskId: uuid("task_id"),
  status: text("status").notNull().default("queued"),
  output: text("output"),
  ranAt: timestamp("ran_at").defaultNow().notNull(),
});

export const reminders = pgTable("kdj_reminders", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  title: text("title").notNull(),
  remindAt: timestamp("remind_at"),
  done: boolean("done").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const links = pgTable("kdj_links", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  url: text("url").notNull(),
  title: text("title"),
  summary: text("summary"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ================= 71–77 · MEMORY & PERSONALIZATION ================= */

export const memoryHistory = pgTable("kdj_memory_history", {
  id: uuid("id").defaultRandom().primaryKey(),
  memoryId: uuid("memory_id"),
  action: text("action").notNull(),
  previousFact: text("previous_fact"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const personas = pgTable("kdj_personas", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  name: text("name").notNull(),
  traits: jsonb("traits").$type<string[]>().notNull().default([]),
  instructions: text("instructions").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const tones = pgTable("kdj_tones", {
  id: uuid("id").defaultRandom().primaryKey(),
  slug: text("slug").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const customInstructions = pgTable("kdj_custom_instructions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  aboutYou: text("about_you").notNull().default(""),
  respondStyle: text("respond_style").notNull().default(""),
  enabled: boolean("enabled").notNull().default(true),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const translationHistory = pgTable("kdj_translation_history", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  sourceText: text("source_text").notNull(),
  targetText: text("target_text"),
  targetLang: text("target_lang").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const promptTemplates = pgTable("kdj_prompt_templates", {
  id: uuid("id").defaultRandom().primaryKey(),
  category: text("category").notNull().default("general"),
  title: text("title").notNull(),
  prompt: text("prompt").notNull(),
  uses: integer("uses").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const promptFavorites = pgTable("kdj_prompt_favorites", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  templateId: uuid("template_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ===================== 78–86 · MODELS & USAGE ======================= */

export const modelCatalog = pgTable("kdj_model_catalog", {
  id: uuid("id").defaultRandom().primaryKey(),
  slug: text("slug").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  tier: text("tier").notNull().default("free"),
  contextWindow: integer("context_window").notNull().default(128000),
  capabilities: jsonb("capabilities").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const modelPricing = pgTable("kdj_model_pricing", {
  id: uuid("id").defaultRandom().primaryKey(),
  modelId: uuid("model_id"),
  inputPer1k: doublePrecision("input_per_1k").notNull().default(0),
  outputPer1k: doublePrecision("output_per_1k").notNull().default(0),
  currency: text("currency").notNull().default("USD"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const usageEvents = pgTable("kdj_usage_events", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  model: text("model").notNull(),
  kind: text("kind").notNull().default("chat"),
  tokensIn: integer("tokens_in").notNull().default(0),
  tokensOut: integer("tokens_out").notNull().default(0),
  cost: doublePrecision("cost").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const usageDaily = pgTable("kdj_usage_daily", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  day: text("day").notNull(),
  messages: integer("messages").notNull().default(0),
  images: integer("images").notNull().default(0),
  tokens: integer("tokens").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const rateLimits = pgTable("kdj_rate_limits", {
  id: uuid("id").defaultRandom().primaryKey(),
  tier: text("tier").notNull().default("free"),
  model: text("model").notNull().default("kdj-4o"),
  perHour: integer("per_hour").notNull().default(80),
  perDay: integer("per_day").notNull().default(1000),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const featureFlags = pgTable("kdj_feature_flags", {
  id: uuid("id").defaultRandom().primaryKey(),
  key: text("key").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  rolloutPct: integer("rollout_pct").notNull().default(100),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const experiments = pgTable("kdj_experiments", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  variants: jsonb("variants").$type<string[]>().notNull().default([]),
  status: text("status").notNull().default("running"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const abAssignments = pgTable("kdj_ab_assignments", {
  id: uuid("id").defaultRandom().primaryKey(),
  experimentId: uuid("experiment_id"),
  userId: uuid("user_id"),
  variant: text("variant").notNull().default("control"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const modelBenchmarks = pgTable("kdj_model_benchmarks", {
  id: uuid("id").defaultRandom().primaryKey(),
  model: text("model").notNull(),
  bench: text("bench").notNull(),
  score: doublePrecision("score").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ===================== 87–94 · SHARING & SOCIAL ===================== */

export const shareViews = pgTable("kdj_share_views", {
  id: uuid("id").defaultRandom().primaryKey(),
  shareId: uuid("share_id"),
  viewerIp: text("viewer_ip"),
  viewedAt: timestamp("viewed_at").defaultNow().notNull(),
});

export const comments = pgTable("kdj_comments", {
  id: uuid("id").defaultRandom().primaryKey(),
  conversationId: uuid("conversation_id"),
  userId: uuid("user_id"),
  body: text("body").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const teams = pgTable("kdj_teams", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  ownerUserId: uuid("owner_user_id"),
  plan: text("plan").notNull().default("team"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const teamMembers = pgTable("kdj_team_members", {
  id: uuid("id").defaultRandom().primaryKey(),
  teamId: uuid("team_id"),
  userId: uuid("user_id"),
  role: text("role").notNull().default("member"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const teamWorkspaces = pgTable("kdj_team_workspaces", {
  id: uuid("id").defaultRandom().primaryKey(),
  teamId: uuid("team_id"),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const bookmarks = pgTable("kdj_bookmarks", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  messageId: uuid("message_id"),
  note: text("note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const exportsTable = pgTable("kdj_exports", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  conversationId: uuid("conversation_id"),
  format: text("format").notNull().default("markdown"),
  status: text("status").notNull().default("ready"),
  url: text("url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const importsTable = pgTable("kdj_imports", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  source: text("source").notNull().default("chatgpt"),
  status: text("status").notNull().default("processing"),
  items: integer("items").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ======================= 95–100 · SYSTEM & OPS ====================== */

export const errorLogs = pgTable("kdj_error_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  route: text("route").notNull(),
  message: text("message").notNull(),
  stack: text("stack"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const analyticsEvents = pgTable("kdj_analytics_events", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id"),
  event: text("event").notNull(),
  props: jsonb("props"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const auditLogs = pgTable("kdj_audit_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  actorId: uuid("actor_id"),
  action: text("action").notNull(),
  targetType: text("target_type"),
  targetId: uuid("target_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const backups = pgTable("kdj_backups", {
  id: uuid("id").defaultRandom().primaryKey(),
  scope: text("scope").notNull().default("full"),
  status: text("status").notNull().default("done"),
  sizeBytes: integer("size_bytes").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const queueJobs = pgTable("kdj_queue_jobs", {
  id: uuid("id").defaultRandom().primaryKey(),
  queue: text("queue").notNull().default("default"),
  payload: jsonb("payload"),
  status: text("status").notNull().default("queued"),
  attempts: integer("attempts").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const appSettings = pgTable("kdj_app_settings", {
  id: uuid("id").defaultRandom().primaryKey(),
  key: text("key").notNull(),
  value: jsonb("value"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

/* ============================ TYPES ================================= */

export type Conversation = typeof conversations.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type CustomGpt = typeof customGpts.$inferSelect;
export type Memory = typeof memories.$inferSelect;
export type GeneratedImage = typeof generatedImages.$inferSelect;
export type ModelCatalog = typeof modelCatalog.$inferSelect;
export type PlanTier = typeof planTiers.$inferSelect;
export type ImageStyle = typeof imageStyles.$inferSelect;
export type PromptTemplate = typeof promptTemplates.$inferSelect;
