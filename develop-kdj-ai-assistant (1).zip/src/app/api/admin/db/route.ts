import { NextResponse } from "next/server";
import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = (await db.execute(sql`
    SELECT relname AS table, n_live_tup::int AS rows
    FROM pg_stat_user_tables
    WHERE relname LIKE 'kdj_%'
    ORDER BY relname ASC
  `)) as { rows?: { table: string; rows: number }[] };
  const tables = rows.rows ?? (rows as unknown as { table: string; rows: number }[]);
  const totalTables = tables.length;
  const totalRows = tables.reduce((a, t) => a + (t.rows || 0), 0);
  return NextResponse.json({ totalTables, totalRows, tables });
}
