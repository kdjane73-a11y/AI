import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(projects).orderBy(desc(projects.createdAt));
  return NextResponse.json({ projects: rows });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const inserted = await db.insert(projects).values({ name: body.name || "Untitled project", color: body.color || "#8b5cf6" }).returning();
  return NextResponse.json({ project: inserted[0] });
}
