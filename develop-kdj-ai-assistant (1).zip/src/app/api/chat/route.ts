import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, messages, memories, generatedImages, customGpts } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { generateKDJResponse, buildTitle, extractMemoryFact, type HistoryItem } from "@/lib/kdj-engine";

export const dynamic = "force-dynamic";

async function tryOpenAI(apiKey: string, model: string, history: HistoryItem[], systemExtra: string) {
  const openaiModel = model === "kdj-mini" ? "gpt-4o-mini" : model === "kdj-o1" ? "o1-mini" : "gpt-4o";
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: openaiModel,
      messages: [
        { role: "system", content: `You are KDJ, an all-access AI like ChatGPT Plus. Helpful, concise, markdown-formatted. ${systemExtra}` },
        ...history.slice(-20),
      ],
      temperature: 0.8,
      max_tokens: 2000,
    }),
  });
  if (!res.ok) throw new Error(`OpenAI ${res.status}`);
  const data = await res.json();
  return data.choices?.[0]?.message?.content as string;
}

async function fetchWebResults(query: string) {
  try {
    const out: { title: string; url: string; snippet: string }[] = [];
    // Wikipedia first (reliable, no key)
    const wiki = await fetch(`https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&origin=*&srlimit=4`, { next: { revalidate: 60 } }).then((r) => r.json()).catch(() => null);
    if (wiki?.query?.search) {
      for (const s of wiki.query.search.slice(0, 3)) {
        out.push({
          title: s.title,
          url: `https://en.wikipedia.org/wiki/${encodeURIComponent(s.title.replace(/ /g, "_"))}`,
          snippet: (s.snippet || "").replace(/<[^>]+>/g, "").slice(0, 220),
        });
      }
    }
    // DuckDuckGo instant answers
    const ddg = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`, { next: { revalidate: 60 } }).then((r) => r.json()).catch(() => null);
    if (ddg?.AbstractText) {
      out.unshift({ title: ddg.Heading || query, url: ddg.AbstractURL || "https://duckduckgo.com", snippet: String(ddg.AbstractText).slice(0, 240) });
    }
    if (ddg?.RelatedTopics?.length && out.length < 5) {
      for (const t of ddg.RelatedTopics.slice(0, 3)) {
        if (t?.Text && t?.FirstURL) out.push({ title: (t.Text as string).slice(0, 70), url: t.FirstURL, snippet: (t.Text as string).slice(0, 200) });
      }
    }
    return out.slice(0, 5);
  } catch {
    return [];
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      message,
      conversationId,
      model = "kdj-4o",
      gptId,
      webSearch = false,
      imageMode = false,
      attachments = [],
    } = body as {
      message: string;
      conversationId?: string;
      model?: string;
      gptId?: string;
      webSearch?: boolean;
      imageMode?: boolean;
      attachments?: { name: string; type: string; size: number; preview?: string; text?: string }[];
    };

    if (!message?.trim() && !attachments?.length) {
      return NextResponse.json({ error: "Empty message" }, { status: 400 });
    }

    // Load / create conversation
    let convId = conversationId;
    if (!convId) {
      const inserted = await db.insert(conversations).values({ title: buildTitle(message || attachments?.[0]?.name || "New chat"), model, gptId: gptId || null }).returning();
      convId = inserted[0].id;
    } else {
      await db.update(conversations).set({ updatedAt: new Date(), model }).where(eq(conversations.id, convId));
    }

    const prevMsgs = await db.select().from(messages).where(eq(messages.conversationId, convId)).orderBy(messages.createdAt);
    const history: HistoryItem[] = prevMsgs.map((m) => ({ role: m.role as "user" | "assistant", content: m.content })).slice(-16);

    // GPT instructions
    let gptInstructions: string | undefined;
    let gptName: string | undefined;
    const convRow = (await db.select().from(conversations).where(eq(conversations.id, convId)))[0];
    const effectiveGptId = gptId || convRow?.gptId;
    if (effectiveGptId) {
      const g = (await db.select().from(customGpts).where(eq(customGpts.id, effectiveGptId)))[0];
      if (g) {
        gptInstructions = `${g.name}: ${g.description}. ${g.instructions}`;
        gptName = g.name;
      }
    }

    const memRows = await db.select().from(memories).orderBy(desc(memories.createdAt)).limit(8);
    const memFacts = memRows.map((m) => m.fact);

    // file context
    const fileContext = (attachments || []).map((a) => (a.text ? `[${a.name}]: ${a.text.slice(0, 4000)}` : "")).filter(Boolean).join("\n\n").slice(0, 6000) || undefined;

    // image attachments -> vision note
    const hasImages = (attachments || []).some((a) => a.type?.startsWith("image/"));
    const visionNote = hasImages ? `\n\n[User attached ${attachments.filter((a) => a.type?.startsWith("image/")).length} image(s): ${attachments.filter((a) => a.type?.startsWith("image/")).map((a) => a.name).join(", ")}. Describe what you see conceptually and answer about it.]` : "";

    let webResults: { title: string; url: string; snippet: string }[] = [];
    if (webSearch) {
      webResults = await fetchWebResults(message.slice(0, 200));
    }

    // Save user message
    await db.insert(messages).values({
      conversationId: convId,
      role: "user",
      content: message + visionNote,
      model,
      attachments: attachments || [],
    });

    // Memory extraction
    const fact = extractMemoryFact(message);
    if (fact) {
      await db.insert(memories).values({ fact }).catch(() => {});
    }

    // Try OpenAI if key present
    const openaiKey = process.env.OPENAI_API_KEY;
    let content = "";
    let reasoning: string | undefined;
    let imageUrl: string | undefined;
    let sources = webResults.length ? webResults : undefined;
    let followups: string[] | undefined;

    if (openaiKey) {
      try {
        const sysExtra = `${gptInstructions || ""} Memories: ${memFacts.join("; ")}. ${fileContext ? "File context: " + fileContext.slice(0, 3000) : ""} ${webResults.length ? "Web results: " + JSON.stringify(webResults).slice(0, 3000) : ""}`;
        content = await tryOpenAI(openaiKey, model, [...history, { role: "user", content: message }], sysExtra);
        if (model === "kdj-o1") reasoning = "Used OpenAI reasoning path with KDJ orchestration.";
      } catch {
        content = "";
      }
    }

    if (!content) {
      const out = generateKDJResponse({
        userMessage: message + (hasImages ? " [image attached — user shared a photo/screenshot]" : ""),
        history,
        model,
        gptInstructions,
        memories: memFacts,
        webResults,
        fileContext,
        imageMode,
      });
      content = out.content;
      reasoning = out.reasoning;
      imageUrl = out.imageUrl;
      if (out.sources) sources = out.sources;
      followups = out.followups;
    }

    if (gptName) content = `> 🤖 **${gptName}** · custom GPT\n\n` + content;

    // Persist image if generated
    if (imageUrl) {
      const promptUsed = message.slice(0, 500);
      await db.insert(generatedImages).values({ prompt: promptUsed, url: imageUrl, style: "vivid", conversationId: convId }).catch(() => {});
    }

    const saved = await db.insert(messages).values({
      conversationId: convId,
      role: "assistant",
      content,
      model,
      reasoning,
      sources: sources || [],
      imageUrl,
    }).returning();

    // Update title if first exchange
    if (prevMsgs.length === 0) {
      await db.update(conversations).set({ title: buildTitle(message) }).where(eq(conversations.id, convId));
    }

    return NextResponse.json({
      conversationId: convId,
      message: saved[0],
      followups,
      webResults: sources,
    });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Chat failed" }, { status: 500 });
  }
}
