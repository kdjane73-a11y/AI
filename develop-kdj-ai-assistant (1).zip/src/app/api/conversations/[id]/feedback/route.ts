import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { messages } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const body = await req.json();
  const { messageId, feedback } = body as { messageId: string; feedback: string };
  await db.update(messages).set({ feedback }).where(eq(messages.id, messageId));
  return NextResponse.json({ ok: true });
}
