import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const conv = (await db.select().from(conversations).where(eq(conversations.id, id)))[0];
  if (!conv) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const msgs = await db.select().from(messages).where(eq(messages.conversationId, id)).orderBy(messages.createdAt);
  return NextResponse.json({ conversation: conv, messages: msgs });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();
  await db.update(conversations).set({ ...body, updatedAt: new Date() }).where(eq(conversations.id, id));
  const conv = (await db.select().from(conversations).where(eq(conversations.id, id)))[0];
  return NextResponse.json({ conversation: conv });
}

export async function DELETE(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await db.delete(messages).where(eq(messages.conversationId, id));
  await db.delete(conversations).where(eq(conversations.id, id));
  return NextResponse.json({ ok: true });
}
