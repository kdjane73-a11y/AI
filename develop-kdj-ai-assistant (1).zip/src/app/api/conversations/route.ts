import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(conversations).orderBy(desc(conversations.updatedAt)).limit(100);
  return NextResponse.json({ conversations: rows });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const inserted = await db.insert(conversations).values({
    title: body.title || "New chat",
    model: body.model || "kdj-4o",
    projectId: body.projectId || null,
    gptId: body.gptId || null,
  }).returning();
  return NextResponse.json({ conversation: inserted[0] });
}
