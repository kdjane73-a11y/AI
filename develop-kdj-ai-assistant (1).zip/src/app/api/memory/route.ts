import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { memories } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(memories).orderBy(desc(memories.createdAt)).limit(50);
  return NextResponse.json({ memories: rows });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  if (!body.fact) return NextResponse.json({ error: "Missing fact" }, { status: 400 });
  const inserted = await db.insert(memories).values({ fact: String(body.fact).slice(0, 500) }).returning();
  return NextResponse.json({ memory: inserted[0] });
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
  await db.delete(memories).where(eq(memories.id, id));
  return NextResponse.json({ ok: true });
}
