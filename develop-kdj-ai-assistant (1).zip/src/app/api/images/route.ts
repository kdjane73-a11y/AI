import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { generatedImages } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(generatedImages).orderBy(desc(generatedImages.createdAt)).limit(40);
  return NextResponse.json({ images: rows });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const prompt = String(body.prompt || "").slice(0, 500);
  if (!prompt) return NextResponse.json({ error: "Missing prompt" }, { status: 400 });
  const style = body.style || "vivid";
  const seed = Math.floor(Math.random() * 999999);
  const styleSuffix = style === "photoreal" ? ", ultra photorealistic, 85mm, natural light" : style === "anime" ? ", anime style, studio ghibli inspired" : style === "cyberpunk" ? ", cyberpunk neon, cinematic" : style === "oil" ? ", oil painting, textured canvas" : ", highly detailed, vivid";
  const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt + styleSuffix)}?width=1024&height=1024&nologo=true&seed=${seed}&model=flux`;
  const inserted = await db.insert(generatedImages).values({ prompt, url, style, conversationId: body.conversationId || null }).returning().catch(() => []);
  return NextResponse.json({ image: inserted?.[0] || { prompt, url, style } });
}
