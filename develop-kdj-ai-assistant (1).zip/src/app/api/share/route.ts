import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { sharedChats, conversations } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const conversationId = body.conversationId;
  if (!conversationId) return NextResponse.json({ error: "Missing conversationId" }, { status: 400 });
  const conv = (await db.select().from(conversations).where(eq(conversations.id, conversationId)))[0];
  const inserted = await db.insert(sharedChats).values({ conversationId, title: conv?.title || "Shared chat" }).returning();
  return NextResponse.json({ shareId: inserted[0].id });
}
