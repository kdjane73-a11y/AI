import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { sharedChats, messages, conversations } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const share = (await db.select().from(sharedChats).where(eq(sharedChats.id, id)))[0];
  if (!share) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const msgs = await db.select().from(messages).where(eq(messages.conversationId, share.conversationId)).orderBy(messages.createdAt);
  const conv = (await db.select().from(conversations).where(eq(conversations.id, share.conversationId)))[0];
  return NextResponse.json({ share, messages: msgs, title: conv?.title || share.title });
}
