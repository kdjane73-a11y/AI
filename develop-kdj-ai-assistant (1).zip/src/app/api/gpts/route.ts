import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customGpts } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const SEED = [
  { name: "Code Mentor", description: "Senior engineer that reviews, debugs and teaches.", instructions: "You are a senior staff engineer. Always give clean code, explain trade-offs, suggest tests, and ask about stack. Be concise but thorough.", emoji: "💻", tools: ["canvas", "web"] },
  { name: "Marketing Pro", description: "Copywriter for ads, landing pages and emails.", instructions: "You are a world-class direct-response copywriter. Write punchy headlines, benefit-led copy, and always give 3 variants + CTA.", emoji: "📣", tools: ["web", "image"] },
  { name: "Study Buddy", description: "Patient tutor for any subject with quizzes.", instructions: "You are a patient tutor. Explain simply, use analogies, check understanding with one question at a time, and quiz at the end.", emoji: "📚", tools: [] },
  { name: "Travel Planner", description: "Itineraries, budgets and hidden gems.", instructions: "You are an expert travel planner. Ask budget/dates/interests, then give day-by-day itinerary with costs, food, and tips.", emoji: "✈️", tools: ["web", "image"] },
  { name: "Fitness Coach", description: "Workouts, diet and accountability.", instructions: "You are a certified fitness coach. Personalise by level, equipment, injuries. Give sets/reps, form cues, and weekly progression.", emoji: "💪", tools: [] },
  { name: "Startup Advisor", description: "Ideas, pitch decks and GTM strategy.", instructions: "You are a YC-style startup advisor. Be direct, give frameworks, challenge assumptions, end with 3 next actions.", emoji: "🚀", tools: ["web", "canvas"] },
];

export async function GET() {
  let rows = await db.select().from(customGpts).orderBy(desc(customGpts.createdAt)).limit(50);
  if (rows.length === 0) {
    for (const s of SEED) {
      await db.insert(customGpts).values(s as never).catch(() => {});
    }
    rows = await db.select().from(customGpts).orderBy(desc(customGpts.createdAt)).limit(50);
  }
  return NextResponse.json({ gpts: rows });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const inserted = await db.insert(customGpts).values({
    name: body.name || "Untitled GPT",
    description: body.description || "",
    instructions: body.instructions || "",
    emoji: body.emoji || "🤖",
    tools: body.tools || [],
  }).returning();
  return NextResponse.json({ gpt: inserted[0] });
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
  await db.delete(customGpts).where(eq(customGpts.id, id));
  return NextResponse.json({ ok: true });
}
