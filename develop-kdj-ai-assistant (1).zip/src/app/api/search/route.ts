import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q") || "";
  if (!q) return NextResponse.json({ results: [] });
  try {
    const out: { title: string; url: string; snippet: string }[] = [];
    const wiki = await fetch(`https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&format=json&origin=*&srlimit=5`).then((r) => r.json()).catch(() => null);
    if (wiki?.query?.search) {
      for (const s of wiki.query.search) {
        out.push({
          title: s.title,
          url: `https://en.wikipedia.org/wiki/${encodeURIComponent(String(s.title).replace(/ /g, "_"))}`,
          snippet: String(s.snippet || "").replace(/<[^>]+>/g, "").slice(0, 240),
        });
      }
    }
    return NextResponse.json({ results: out });
  } catch {
    return NextResponse.json({ results: [] });
  }
}
