import KDJApp from "@/components/KDJApp";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <KDJApp />;
}
