import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "KDJ — All-Access AI (ChatGPT Plus Features)",
  description: "KDJ is your all-access AI: chat, reasoning, vision, image studio, voice, web browsing, canvas, custom GPTs, memory and file understanding.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#0a0a10] text-zinc-100 antialiased">{children}</body>
    </html>
  );
}
