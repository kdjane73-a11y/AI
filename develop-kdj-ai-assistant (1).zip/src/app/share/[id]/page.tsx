"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import Link from "next/link";

type Msg = { id: string; role: string; content: string; createdAt: string };

export default function SharePage() {
  const params = useParams();
  const id = params?.id as string;
  const [title, setTitle] = useState("Shared chat");
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (!id) return;
    fetch(`/api/share/${id}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) setErr("This shared chat doesn't exist or was removed.");
        else {
          setMsgs(d.messages || []);
          setTitle(d.title || "Shared chat");
        }
      })
      .catch(() => setErr("Couldn't load this chat."));
  }, [id]);

  return (
    <div className="min-h-screen bg-[#0a0a10] text-zinc-100">
      <header className="flex items-center gap-3 border-b border-white/10 px-5 py-3.5">
        <div className="grid h-9 w-9 place-items-center rounded-2xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-400 text-lg font-black">K</div>
        <div>
          <div className="font-extrabold">KDJ <span className="ml-1 rounded bg-gradient-to-r from-violet-500 to-cyan-400 px-1.5 py-0.5 text-[10px]">PLUS</span></div>
          <div className="text-xs text-zinc-500">{title}</div>
        </div>
        <Link href="/" className="ml-auto rounded-xl bg-white px-4 py-2 text-xs font-bold text-black">Try KDJ free</Link>
      </header>
      <main className="mx-auto max-w-3xl px-5 py-8">
        {err ? (
          <p className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 text-center text-sm text-zinc-400">{err}</p>
        ) : (
          <div className="space-y-5">
            {msgs.map((m) => (
              <div key={m.id} className={`flex gap-3 ${m.role === "user" ? "justify-end" : ""}`}>
                {m.role === "assistant" && <div className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 font-black">K</div>}
                <div className={`max-w-[90%] ${m.role === "user" ? "rounded-2xl bg-violet-600/80 px-4 py-2.5 text-[15px]" : "w-full text-[15px] leading-relaxed"}`}>
                  {m.role === "user" ? (
                    <span className="whitespace-pre-wrap">{m.content}</span>
                  ) : (
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
                  )}
                </div>
              </div>
            ))}
            {msgs.length === 0 && !err && <p className="text-center text-sm text-zinc-500">Loading shared conversation…</p>}
          </div>
        )}
      </main>
    </div>
  );
}
