"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Plus, Search, MessageSquare, Pin, Archive, Trash2, Pencil, X, Menu, Send,
  Paperclip, Mic, Globe, Image as ImageIcon, Sparkles, Bot, Cpu, Zap, Eye,
  LayoutDashboard, Brain, Share2, Copy, Check, ThumbsUp, ThumbsDown, RotateCcw,
  Volume2, VolumeX, Square, ChevronDown, FolderPlus, Folder, Library, Settings,
  Wand2, Play, Code2, PanelRightOpen, PanelRightClose, MicOff, CornerDownLeft,
  Lightbulb, Clock, Star, ChevronRight, ExternalLink, Loader2, FileText, Link2,
} from "lucide-react";

type Msg = {
  id: string;
  conversationId: string;
  role: string;
  content: string;
  model?: string | null;
  attachments?: { name: string; type: string; size: number; preview?: string; text?: string }[] | null;
  imageUrl?: string | null;
  reasoning?: string | null;
  sources?: { title: string; url: string; snippet: string }[] | null;
  feedback?: string | null;
  createdAt: string;
};

type Conv = { id: string; title: string; model: string; projectId?: string | null; pinned: boolean; archived: boolean; gptId?: string | null; updatedAt: string; createdAt: string };
type Gpt = { id: string; name: string; description: string; instructions: string; emoji: string; tools: string[] };
type GenImg = { id: string; prompt: string; url: string; style: string; createdAt: string };
type Mem = { id: string; fact: string; createdAt: string };

const MODELS = [
  { id: "kdj-4o", name: "KDJ-4o", desc: "Smartest · chat, code, files", icon: Sparkles, color: "text-violet-300", badge: "PLUS" },
  { id: "kdj-o1", name: "KDJ-o1", desc: "Deep reasoning · math, logic", icon: Brain, color: "text-cyan-300", badge: "REASON" },
  { id: "kdj-mini", name: "KDJ-mini", desc: "Lightning fast · everyday", icon: Zap, color: "text-amber-300", badge: "FAST" },
  { id: "kdj-vision", name: "KDJ Vision", desc: "See images · screenshots", icon: Eye, color: "text-emerald-300", badge: "VISION" },
  { id: "kdj-canvas", name: "KDJ Canvas", desc: "Live code + preview", icon: LayoutDashboard, color: "text-pink-300", badge: "CANVAS" },
  { id: "kdj-image", name: "KDJ Image", desc: "Generate art · posters", icon: ImageIcon, color: "text-orange-300", badge: "ART" },
];

const SUGGESTIONS = [
  { icon: Code2, title: "Build a landing page", prompt: "Write a stunning HTML landing page for my AI startup with hero, features and pricing" },
  { icon: ImageIcon, title: "Generate an image", prompt: "Generate an image of a futuristic neon city floating above clouds at sunset, cinematic" },
  { icon: Lightbulb, title: "Startup ideas", prompt: "Give me 5 startup ideas I can build this weekend with AI" },
  { icon: FileText, title: "Write an email", prompt: "Write a professional email to my team about our project update and next steps" },
  { icon: Cpu, title: "Explain AI simply", prompt: "Explain how large language models work like I'm 12 years old" },
  { icon: Globe, title: "Research anything", prompt: "What are the latest breakthroughs in AI? Enable web search mentally and summarise" },
];

function extractHtmlBlocks(content: string): { lang: string; code: string }[] {
  const out: { lang: string; code: string }[] = [];
  const re = /```(\w+)?\n([\s\S]*?)```/g;
  let m;
  while ((m = re.exec(content)) !== null) {
    out.push({ lang: (m[1] || "text").toLowerCase(), code: m[2] });
  }
  return out;
}

function Markdown({ content, onOpenCanvas }: { content: string; onOpenCanvas: (code: string, lang: string) => void }) {
  const [copied, setCopied] = useState<string | null>(null);
  return (
    <div className="kdj-md text-[15px] leading-[1.75]">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          a: ({ ...props }) => <a {...props} target="_blank" rel="noreferrer" className="text-violet-300 underline decoration-violet-400/40 underline-offset-2 hover:text-violet-200" />,
          img: ({ ...props }) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img {...props} alt={props.alt || "KDJ generated"} className="my-3 max-h-[420px] w-auto max-w-full rounded-2xl border border-white/10 shadow-2xl" loading="lazy" />
          ),
          table: ({ ...props }) => <div className="my-3 overflow-x-auto rounded-xl border border-white/10"><table {...props} className="w-full text-sm" /></div>,
          th: ({ ...props }) => <th {...props} className="border-b border-white/10 bg-white/5 px-3 py-2 text-left font-semibold" />,
          td: ({ ...props }) => <td {...props} className="border-b border-white/5 px-3 py-2 align-top" />,
          h1: ({ ...props }) => <h1 {...props} className="mb-2 mt-1 text-2xl font-extrabold tracking-tight" />,
          h2: ({ ...props }) => <h2 {...props} className="mb-2 mt-4 text-xl font-bold tracking-tight" />,
          h3: ({ ...props }) => <h3 {...props} className="mb-1 mt-3 text-base font-bold" />,
          ul: ({ ...props }) => <ul {...props} className="my-2 list-disc space-y-1 pl-5" />,
          ol: ({ ...props }) => <ol {...props} className="my-2 list-decimal space-y-1 pl-5" />,
          blockquote: ({ ...props }) => <blockquote {...props} className="my-2 rounded-r-xl border-l-4 border-violet-500/60 bg-violet-500/5 py-2 pl-4 pr-3 italic text-zinc-300" />,
          p: ({ ...props }) => <p {...props} className="my-2" />,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          code: ({ className, children, ...props }: any) => {
            const text = String(children ?? "");
            const isBlock = (className || "").includes("language-") || text.includes("\n");
            if (!isBlock) return <code className="rounded-md bg-white/10 px-1.5 py-0.5 font-mono text-[13px] text-amber-200" {...props}>{children}</code>;
            const lang = (className || "").replace("language-", "") || "code";
            return (
              <span className="my-3 block overflow-hidden rounded-2xl border border-white/10 bg-[#0b0b12]">
                <span className="flex items-center justify-between border-b border-white/10 bg-white/[0.03] px-4 py-2">
                  <span className="font-mono text-xs uppercase tracking-widest text-zinc-400">{lang}</span>
                  <span className="flex gap-1.5">
                    <button
                      onClick={() => { navigator.clipboard.writeText(text); setCopied(text.slice(0, 20)); setTimeout(() => setCopied(null), 1500); }}
                      className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs text-zinc-300 hover:bg-white/10"
                    >{copied === text.slice(0, 20) ? <Check size={13} /> : <Copy size={13} />}{copied === text.slice(0, 20) ? "Copied" : "Copy"}</button>
                    <button onClick={() => onOpenCanvas(text, lang)} className="flex items-center gap-1 rounded-lg bg-violet-500/20 px-2 py-1 text-xs text-violet-200 hover:bg-violet-500/30"><Play size={13} />Canvas</button>
                  </span>
                </span>
                <code className="block overflow-x-auto p-4 font-mono text-[13px] leading-relaxed text-zinc-100" {...props}>{children}</code>
              </span>
            );
          },
          pre: ({ ...props }) => <pre {...props} className="bg-transparent p-0" />,
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}

export default function KDJApp() {
  const [convs, setConvs] = useState<Conv[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [model, setModel] = useState("kdj-4o");
  const [modelOpen, setModelOpen] = useState(false);
  const [webSearch, setWebSearch] = useState(true);
  const [imageMode, setImageMode] = useState(false);
  const [gptId, setGptId] = useState<string | null>(null);
  const [attachments, setAttachments] = useState<{ name: string; type: string; size: number; preview?: string; text?: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [streamText, setStreamText] = useState("");
  const [followups, setFollowups] = useState<string[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [searchQ, setSearchQ] = useState("");
  const [gpts, setGpts] = useState<Gpt[]>([]);
  const [genImages, setGenImages] = useState<GenImg[]>([]);
  const [mems, setMems] = useState<Mem[]>([]);
  const [view, setView] = useState<"chat" | "gpts" | "library" | "memory">("chat");
  const [canvasOpen, setCanvasOpen] = useState(false);
  const [canvasCode, setCanvasCode] = useState("");
  const [canvasLang, setCanvasLang] = useState("html");
  const [canvasTab, setCanvasTab] = useState<"preview" | "code">("preview");
  const [showImgStudio, setShowImgStudio] = useState(false);
  const [imgPrompt, setImgPrompt] = useState("");
  const [imgStyle, setImgStyle] = useState("vivid");
  const [imgLoading, setImgLoading] = useState(false);
  const [showGptBuilder, setShowGptBuilder] = useState(false);
  const [newGpt, setNewGpt] = useState({ name: "", description: "", instructions: "", emoji: "🤖" });
  const [showSettings, setShowSettings] = useState(false);
  const [dbStats, setDbStats] = useState<{ totalTables: number; totalRows: number; tables: { table: string; rows: number }[] } | null>(null);
  const [autoTTS, setAutoTTS] = useState(false);
  const [enterToSend, setEnterToSend] = useState(true);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [sharing, setSharing] = useState(false);
  const [voiceOpen, setVoiceOpen] = useState(false);
  const [listening, setListening] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState("");
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameVal, setRenameVal] = useState("");
  const [showArchived, setShowArchived] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const bottomRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recogRef = useRef<unknown>(null);

  const activeGpt = useMemo(() => gpts.find((g) => g.id === gptId) || null, [gpts, gptId]);
  const activeConv = useMemo(() => convs.find((c) => c.id === activeId) || null, [convs, activeId]);

  const showToast = (t: string) => { setToast(t); setTimeout(() => setToast(null), 2200); };

  const loadConvs = useCallback(async () => {
    const r = await fetch("/api/conversations").then((x) => x.json()).catch(() => null);
    if (r?.conversations) setConvs(r.conversations);
  }, []);
  const loadGpts = useCallback(async () => {
    const r = await fetch("/api/gpts").then((x) => x.json()).catch(() => null);
    if (r?.gpts) setGpts(r.gpts);
  }, []);
  const loadImgs = useCallback(async () => {
    const r = await fetch("/api/images").then((x) => x.json()).catch(() => null);
    if (r?.images) setGenImages(r.images);
  }, []);
  const loadMems = useCallback(async () => {
    const r = await fetch("/api/memory").then((x) => x.json()).catch(() => null);
    if (r?.memories) setMems(r.memories);
  }, []);

  useEffect(() => { loadConvs(); loadGpts(); loadImgs(); loadMems(); }, [loadConvs, loadGpts, loadImgs, loadMems]);
  useEffect(() => {
    if (showSettings) {
      fetch("/api/admin/db").then((r) => r.json()).then((d) => setDbStats(d)).catch(() => {});
    }
  }, [showSettings]);
  useEffect(() => {
    const w = window.innerWidth < 900;
    if (w) setSidebarOpen(false);
  }, []);

  const loadMessages = useCallback(async (id: string) => {
    const r = await fetch(`/api/conversations/${id}`).then((x) => x.json()).catch(() => null);
    if (r?.messages) {
      setMsgs(r.messages);
      if (r.conversation?.model) setModel(r.conversation.model);
      if (r.conversation?.gptId) setGptId(r.conversation.gptId);
    }
  }, []);

  useEffect(() => {
    if (activeId) loadMessages(activeId);
    else setMsgs([]);
    setFollowups([]);
    setShareUrl(null);
  }, [activeId, loadMessages]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, streamText, loading]);

  const speak = useCallback((text: string) => {
    try {
      const clean = text.replace(/```[\s\S]*?```/g, " code block ").replace(/[#*`>\[\]()!]/g, "").slice(0, 600);
      const u = new SpeechSynthesisUtterance(clean);
      u.rate = 1.02;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u);
    } catch { /* noop */ }
  }, []);

  const send = useCallback(async (override?: string) => {
    const text = (override ?? input).trim();
    if ((!text && attachments.length === 0) || loading) return;
    setLoading(true);
    setFollowups([]);
    const userOptimistic: Msg = {
      id: `tmp-${Date.now()}`, conversationId: activeId || "new", role: "user",
      content: text || "(attachment)", attachments: [...attachments], createdAt: new Date().toISOString(),
    };
    setMsgs((p) => [...p, userOptimistic]);
    setInput("");
    setStreamText("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";
    const atts = [...attachments];
    setAttachments([]);

    // fake streaming dots
    let dots = 0;
    const dotTimer = setInterval(() => { dots++; setStreamText("KDJ is thinking" + ".".repeat((dots % 3) + 1)); }, 450);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, conversationId: activeId, model, gptId, webSearch, imageMode: imageMode || model === "kdj-image", attachments: atts }),
      }).then((r) => r.json());

      clearInterval(dotTimer);
      if (res.error) throw new Error(res.error);
      if (!activeId && res.conversationId) {
        setActiveId(res.conversationId);
        loadConvs();
      } else loadConvs();
      // typewriter reveal
      const full: string = res.message.content as string;
      setStreamText("");
      let i = 0;
      const chunk = Math.max(8, Math.floor(full.length / 90));
      await new Promise<void>((resolve) => {
        const t = setInterval(() => {
          i += chunk;
          if (i >= full.length) { setStreamText(""); clearInterval(t); resolve(); }
          else setStreamText(full.slice(0, i));
        }, 18);
      });
      await loadMessages(res.conversationId);
      setFollowups(res.followups || []);
      if (res.message?.imageUrl) loadImgs();
      if (autoTTS) speak(full);
      // auto-open canvas for html
      const blocks = extractHtmlBlocks(full);
      const html = blocks.find((b) => b.lang === "html");
      if ((model === "kdj-canvas" || html) && html) {
        setCanvasCode(html.code); setCanvasLang("html"); setCanvasTab("preview"); setCanvasOpen(true);
      }
    } catch {
      clearInterval(dotTimer);
      setStreamText("");
      showToast("Something glitched — try again");
      setMsgs((p) => p.filter((m) => m.id !== userOptimistic.id));
    } finally {
      setLoading(false);
      setStreamText("");
    }
  }, [input, attachments, loading, activeId, model, gptId, webSearch, imageMode, loadConvs, loadMessages, loadImgs, autoTTS, speak]);

  const regenerate = useCallback(async () => {
    const lastUser = [...msgs].reverse().find((m) => m.role === "user");
    if (!lastUser || loading) return;
    setMsgs((p) => p.filter((m) => m.id !== lastUser.id || m.role !== "assistant"));
    // remove last assistant too optimistically then resend
    const withoutLastAssistant = (() => {
      const idx = msgs.map((m) => m.role).lastIndexOf("assistant");
      if (idx >= 0) { const c = [...msgs]; c.splice(idx, 1); return c; }
      return msgs;
    })();
    setMsgs(withoutLastAssistant.filter((m) => m.id !== `tmp-${Date.now()}`));
    await send(lastUser.content);
  }, [msgs, loading, send]);

  const newChat = () => { setActiveId(null); setMsgs([]); setGptId(null); setFollowups([]); setView("chat"); setInput(""); setShareUrl(null); };

  const handleFiles = async (files: FileList | null) => {
    if (!files) return;
    const arr: typeof attachments = [];
    for (const f of Array.from(files).slice(0, 5)) {
      if (f.type.startsWith("image/")) {
        const preview = await new Promise<string>((res) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.readAsDataURL(f); });
        arr.push({ name: f.name, type: f.type, size: f.size, preview });
      } else {
        const text = await f.text().then((t) => t.slice(0, 6000)).catch(() => "");
        arr.push({ name: f.name, type: f.type || "text/plain", size: f.size, text });
      }
    }
    setAttachments((p) => [...p, ...arr]);
    showToast(`${arr.length} file(s) attached`);
  };

  const toggleMic = () => {
    try {
      const SR = (window as unknown as { webkitSpeechRecognition?: new () => unknown; SpeechRecognition?: new () => unknown }).webkitSpeechRecognition || (window as unknown as { SpeechRecognition?: new () => unknown }).SpeechRecognition;
      if (!SR) { showToast("Voice input needs Chrome"); return; }
      if (listening) {
        (recogRef.current as { stop?: () => void } | null)?.stop?.();
        setListening(false);
        return;
      }
      const recog = new (SR as new () => { lang: string; interimResults: boolean; onresult: ((e: { results: { [i: number]: { [j: number]: { transcript: string } } } }) => void) | null; onend: (() => void) | null; start: () => void; stop: () => void })();
      recog.lang = "en-US";
      recog.interimResults = true;
      recogRef.current = recog;
      recog.onresult = (e) => {
        const t = e.results[0]?.[0]?.transcript || "";
        setInput(t);
        if (textareaRef.current) { textareaRef.current.style.height = "auto"; textareaRef.current.style.height = Math.min(200, textareaRef.current.scrollHeight) + "px"; }
      };
      recog.onend = () => setListening(false);
      recog.start();
      setListening(true);
    } catch { showToast("Mic unavailable"); }
  };

  const openCanvas = (code: string, lang: string) => { setCanvasCode(code); setCanvasLang(lang); setCanvasTab(lang === "html" ? "preview" : "code"); setCanvasOpen(true); };

  const doShare = async () => {
    if (!activeId) return;
    setSharing(true);
    const r = await fetch("/api/share", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ conversationId: activeId }) }).then((x) => x.json()).catch(() => null);
    setSharing(false);
    if (r?.shareId) {
      const url = `${window.location.origin}/share/${r.shareId}`;
      setShareUrl(url);
      navigator.clipboard.writeText(url).catch(() => {});
      showToast("Share link copied");
    }
  };

  const doImageGen = async () => {
    if (!imgPrompt.trim() || imgLoading) return;
    setImgLoading(true);
    const r = await fetch("/api/images", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prompt: imgPrompt, style: imgStyle, conversationId: activeId }) }).then((x) => x.json()).catch(() => null);
    setImgLoading(false);
    if (r?.image) {
      loadImgs();
      setShowImgStudio(false);
      const md = `![${imgPrompt}](${r.image.url})`;
      if (!activeId) {
        // create chat with image
        await send(`Generate an image of: ${imgPrompt} (${imgStyle} style)\n\n${md}`);
      } else {
        showToast("Image added to library");
      }
      setImgPrompt("");
    }
  };

  const doCreateGpt = async () => {
    if (!newGpt.name.trim()) { showToast("Give your GPT a name"); return; }
    const r = await fetch("/api/gpts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(newGpt) }).then((x) => x.json());
    if (r?.gpt) {
      loadGpts();
      setShowGptBuilder(false);
      setNewGpt({ name: "", description: "", instructions: "", emoji: "🤖" });
      setGptId(r.gpt.id);
      setView("chat");
      showToast(`GPT "${r.gpt.name}" created`);
    }
  };

  const feedback = async (messageId: string, fb: string) => {
    if (!activeId) return;
    setMsgs((p) => p.map((m) => (m.id === messageId ? { ...m, feedback: fb } : m)));
    await fetch(`/api/conversations/${activeId}/feedback`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messageId, feedback: fb }) }).catch(() => {});
  };

  const filtered = useMemo(() => {
    let list = [...convs];
    if (!showArchived) list = list.filter((c) => !c.archived);
    else list = list.filter((c) => c.archived);
    if (searchQ.trim()) {
      const q = searchQ.toLowerCase();
      list = list.filter((c) => c.title.toLowerCase().includes(q));
    }
    return list.sort((a, b) => (a.pinned === b.pinned ? +new Date(b.updatedAt) - +new Date(a.updatedAt) : a.pinned ? -1 : 1));
  }, [convs, searchQ, showArchived]);

  const startVoiceMode = () => { setVoiceOpen(true); setVoiceTranscript(""); };
  const voiceAsk = async (text: string) => {
    if (!text.trim()) return;
    setVoiceTranscript(text);
    setInput(text);
    setVoiceOpen(false);
    await send(text);
  };

  const currentModel = MODELS.find((m) => m.id === model) || MODELS[0];

  return (
    <div className="flex h-screen overflow-hidden bg-[#0a0a10] text-zinc-100">
      {/* SIDEBAR */}
      <aside className={`${sidebarOpen ? "w-[290px]" : "w-0"} hidden shrink-0 flex-col overflow-hidden border-r border-white/10 bg-[#111116] transition-all duration-300 md:flex`}>
        <div className="flex items-center justify-between px-4 pb-2 pt-4">
          <div className="flex items-center gap-2.5">
            <div className="grid h-9 w-9 place-items-center rounded-2xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-400 text-lg font-black shadow-lg shadow-violet-500/30">K</div>
            <div>
              <div className="text-[15px] font-extrabold tracking-tight">KDJ <span className="ml-1 rounded-md bg-gradient-to-r from-violet-500 to-cyan-400 px-1.5 py-0.5 text-[10px] font-bold text-white">PLUS</span></div>
              <div className="text-[11px] text-zinc-500">All-access AI</div>
            </div>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="rounded-lg p-1.5 text-zinc-500 hover:bg-white/5 hover:text-white"><PanelRightClose size={17} /></button>
        </div>
        <div className="px-3">
          <button onClick={newChat} className="flex w-full items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-2.5 text-sm font-semibold shadow-lg shadow-violet-600/25 transition hover:brightness-110">
            <Plus size={16} /> New chat <kbd className="ml-auto hidden rounded bg-white/20 px-1.5 text-[10px] lg:block">⌘K</kbd>
          </button>
          <div className="relative mt-2">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input value={searchQ} onChange={(e) => setSearchQ(e.target.value)} placeholder="Search chats…" className="w-full rounded-xl border border-white/10 bg-white/[0.03] py-2 pl-9 pr-3 text-sm outline-none placeholder:text-zinc-600 focus:border-violet-500/50" />
          </div>
        </div>
        <div className="mt-2 flex gap-1 px-3 text-[12px]">
          {(["chat", "gpts", "library", "memory"] as const).map((v) => (
            <button key={v} onClick={() => setView(v)} className={`flex-1 rounded-lg px-2 py-1.5 font-semibold capitalize transition ${view === v ? "bg-white/10 text-white" : "text-zinc-500 hover:text-zinc-200"}`}>
              {v === "chat" ? "Chats" : v === "gpts" ? "GPTs" : v}
            </button>
          ))}
        </div>

        <div className="mt-2 flex-1 overflow-y-auto px-2 pb-4">
          {view === "chat" && (
            <>
              <button onClick={() => setShowArchived(!showArchived)} className="mx-2 mb-1 flex items-center gap-1 text-[11px] uppercase tracking-widest text-zinc-600 hover:text-zinc-300">
                <Archive size={12} /> {showArchived ? "Archived" : "History"} <ChevronRight size={12} className={`transition ${showArchived ? "rotate-90" : ""}`} />
              </button>
              {filtered.length === 0 && <p className="px-4 py-6 text-center text-xs text-zinc-600">No conversations yet.<br />Start one above ✨</p>}
              {filtered.map((c) => (
                <div key={c.id} onClick={() => { setActiveId(c.id); setView("chat"); }} className={`group relative mb-0.5 cursor-pointer rounded-xl px-3 py-2.5 transition ${activeId === c.id ? "bg-white/[0.07]" : "hover:bg-white/[0.04]"}`}>
                  <div className="flex items-center gap-2">
                    <MessageSquare size={14} className="shrink-0 text-zinc-500" />
                    {renamingId === c.id ? (
                      <input autoFocus value={renameVal} onChange={(e) => setRenameVal(e.target.value)} onBlur={async () => { if (renameVal.trim()) { await fetch(`/api/conversations/${c.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: renameVal }) }); loadConvs(); } setRenamingId(null); }} onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); }} onClick={(e) => e.stopPropagation()} className="w-full rounded bg-white/10 px-1 text-sm outline-none" />
                    ) : (
                      <span className="truncate text-[13.5px] text-zinc-200">{c.title}</span>
                    )}
                    {c.pinned && <Pin size={11} className="ml-auto shrink-0 text-violet-400" />}
                  </div>
                  <div className="absolute right-1.5 top-1/2 hidden -translate-y-1/2 items-center gap-0.5 rounded-lg bg-[#1c1c24] p-0.5 shadow-xl group-hover:flex">
                    {[
                      { icon: Pin, fn: async () => { await fetch(`/api/conversations/${c.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pinned: !c.pinned }) }); loadConvs(); } },
                      { icon: Pencil, fn: () => { setRenamingId(c.id); setRenameVal(c.title); } },
                      { icon: Archive, fn: async () => { await fetch(`/api/conversations/${c.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ archived: !c.archived }) }); loadConvs(); if (activeId === c.id) newChat(); } },
                      { icon: Trash2, fn: async () => { if (confirm("Delete this chat?")) { await fetch(`/api/conversations/${c.id}`, { method: "DELETE" }); loadConvs(); if (activeId === c.id) newChat(); } } },
                    ].map((b, i) => (
                      <button key={i} onClick={(e) => { e.stopPropagation(); b.fn(); }} className="rounded-md p-1.5 text-zinc-400 hover:bg-white/10 hover:text-white"><b.icon size={13} /></button>
                    ))}
                  </div>
                </div>
              ))}
            </>
          )}
          {view === "gpts" && (
            <div className="space-y-2 p-1">
              <button onClick={() => setShowGptBuilder(true)} className="flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-violet-500/40 bg-violet-500/5 px-3 py-2.5 text-sm font-semibold text-violet-200 hover:bg-violet-500/10"><Plus size={15} /> Build a GPT</button>
              {gpts.map((g) => (
                <div key={g.id} className={`rounded-xl border p-3 transition ${gptId === g.id ? "border-violet-500/60 bg-violet-500/10" : "border-white/10 bg-white/[0.02] hover:border-white/20"}`}>
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{g.emoji}</span>
                    <div className="min-w-0">
                      <div className="truncate text-sm font-bold">{g.name}</div>
                      <div className="truncate text-xs text-zinc-500">{g.description}</div>
                    </div>
                  </div>
                  <div className="mt-2 flex gap-1.5">
                    <button onClick={() => { setGptId(g.id); newChat(); setGptId(g.id); setView("chat"); showToast(`Using ${g.name}`); }} className="flex-1 rounded-lg bg-white/10 px-2 py-1.5 text-xs font-semibold hover:bg-white/15">Use</button>
                    <button onClick={async () => { await fetch(`/api/gpts?id=${g.id}`, { method: "DELETE" }); loadGpts(); }} className="rounded-lg px-2 py-1.5 text-zinc-500 hover:bg-white/10 hover:text-red-300"><Trash2 size={13} /></button>
                  </div>
                </div>
              ))}
            </div>
          )}
          {view === "library" && (
            <div className="grid grid-cols-2 gap-2 p-1">
              {genImages.length === 0 && <p className="col-span-2 px-2 py-8 text-center text-xs text-zinc-600">No images yet.<br />Generate from Image Studio 🎨</p>}
              {genImages.map((im) => (
                // eslint-disable-next-line @next/next/no-img-element
                <div key={im.id} className="group relative overflow-hidden rounded-xl border border-white/10">
                  <img src={im.url} alt={im.prompt} className="aspect-square w-full object-cover" loading="lazy" />
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent p-2 pt-6 text-[10px] text-zinc-200 opacity-0 transition group-hover:opacity-100">{im.prompt.slice(0, 60)}</div>
                </div>
              ))}
            </div>
          )}
          {view === "memory" && (
            <div className="space-y-2 p-1">
              <p className="px-2 text-[11px] uppercase tracking-widest text-zinc-600">What KDJ remembers</p>
              {mems.length === 0 && <p className="px-2 py-4 text-center text-xs text-zinc-600">Nothing stored yet.<br />Say “remember that…” 🧠</p>}
              {mems.map((m) => (
                <div key={m.id} className="flex items-start gap-2 rounded-xl border border-white/10 bg-white/[0.02] p-2.5 text-xs">
                  <Brain size={13} className="mt-0.5 shrink-0 text-violet-300" />
                  <span className="flex-1 text-zinc-300">{m.fact}</span>
                  <button onClick={async () => { await fetch(`/api/memory?id=${m.id}`, { method: "DELETE" }); loadMems(); }} className="text-zinc-600 hover:text-red-300"><X size={13} /></button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="border-t border-white/10 p-2">
          <button onClick={() => setShowImgStudio(true)} className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-sm text-zinc-300 hover:bg-white/5"><ImageIcon size={16} className="text-orange-300" /> Image Studio</button>
          <button onClick={() => setShowSettings(true)} className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-sm text-zinc-300 hover:bg-white/5"><Settings size={16} className="text-zinc-500" /> Settings</button>
          <div className="mx-3 mb-1 mt-2 flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600/20 to-cyan-500/10 px-3 py-2">
            <div className="h-7 w-7 rounded-full bg-gradient-to-br from-violet-400 to-cyan-300 text-center text-sm font-bold leading-7 text-black">U</div>
            <div className="text-xs"><div className="font-bold">You · Plus</div><div className="text-emerald-300">● KDJ online</div></div>
          </div>
        </div>
      </aside>

      {/* MAIN */}
      <main className="relative flex min-w-0 flex-1 flex-col">
        {/* topbar */}
        <header className="flex items-center gap-2 border-b border-white/10 bg-[#0e0e14]/90 px-3 py-2.5 backdrop-blur md:px-5">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="rounded-lg p-2 text-zinc-400 hover:bg-white/5 md:hidden"><Menu size={18} /></button>
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="hidden rounded-lg p-2 text-zinc-400 hover:bg-white/5 md:block">{sidebarOpen ? <PanelRightClose size={18} /> : <PanelRightOpen size={18} />}</button>
          <div className="relative">
            <button onClick={() => setModelOpen(!modelOpen)} className="flex items-center gap-2 rounded-xl px-3 py-1.5 hover:bg-white/5">
              <currentModel.icon size={17} className={currentModel.color} />
              <span className="font-bold">{currentModel.name}</span>
              <span className="hidden rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-bold text-zinc-400 sm:block">{currentModel.badge}</span>
              <ChevronDown size={14} className="text-zinc-500" />
            </button>
            {modelOpen && (
              <div className="absolute left-0 top-full z-50 mt-2 w-[300px] rounded-2xl border border-white/10 bg-[#17171f] p-1.5 shadow-2xl">
                {MODELS.map((m) => (
                  <button key={m.id} onClick={() => { setModel(m.id); setImageMode(m.id === "kdj-image"); setModelOpen(false); }} className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left hover:bg-white/5 ${model === m.id ? "bg-white/[0.07]" : ""}`}>
                    <m.icon size={18} className={m.color} />
                    <span className="flex-1"><span className="flex items-center gap-2 text-sm font-bold">{m.name} {model === m.id && <Check size={14} className="text-emerald-400" />}</span><span className="text-xs text-zinc-500">{m.desc}</span></span>
                  </button>
                ))}
              </div>
            )}
          </div>
          {activeGpt && (
            <button onClick={() => setGptId(null)} className="hidden items-center gap-1.5 rounded-full border border-violet-500/40 bg-violet-500/10 px-3 py-1 text-xs font-semibold text-violet-200 sm:flex">
              {activeGpt.emoji} {activeGpt.name} <X size={12} />
            </button>
          )}
          <div className="ml-auto flex items-center gap-1.5">
            <button onClick={doShare} disabled={!activeId || sharing} className="flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold text-zinc-300 hover:bg-white/5 disabled:opacity-40">
              {sharing ? <Loader2 size={14} className="animate-spin" /> : <Share2 size={14} />}<span className="hidden sm:inline">Share</span>
            </button>
            <button onClick={() => setCanvasOpen(!canvasOpen)} className={`rounded-xl p-2 ${canvasOpen ? "bg-violet-500/20 text-violet-200" : "text-zinc-400 hover:bg-white/5"}`} title="Canvas"><PanelRightOpen size={17} /></button>
            <button onClick={startVoiceMode} className="flex items-center gap-1.5 rounded-xl bg-white px-3 py-2 text-xs font-bold text-black hover:bg-zinc-200"><Mic size={14} /> Voice</button>
          </div>
        </header>

        {shareUrl && (
          <div className="flex items-center gap-2 border-b border-emerald-500/20 bg-emerald-500/10 px-4 py-2 text-xs">
            <Link2 size={13} className="text-emerald-300" />
            <span className="truncate text-emerald-100">{shareUrl}</span>
            <button onClick={() => { navigator.clipboard.writeText(shareUrl); showToast("Copied"); }} className="ml-auto flex items-center gap-1 rounded-lg bg-emerald-500/20 px-2 py-1 font-bold text-emerald-100"><Copy size={12} /> Copy</button>
            <button onClick={() => setShareUrl(null)}><X size={13} /></button>
          </div>
        )}

        {/* messages */}
        <div className="flex-1 overflow-y-auto">
          {msgs.length === 0 && !loading ? (
            <div className="mx-auto max-w-3xl px-5 pb-40 pt-10 text-center md:pt-16">
              <div className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-400 text-3xl font-black shadow-2xl shadow-violet-500/40">K</div>
              <h1 className="mt-5 text-3xl font-black tracking-tight md:text-4xl">Hey, I&apos;m <span className="bg-gradient-to-r from-violet-400 via-fuchsia-300 to-cyan-300 bg-clip-text text-transparent">KDJ</span></h1>
              <p className="mx-auto mt-2 max-w-md text-sm text-zinc-400">Chat · Code · Images · Voice · Web · Files · Memory · Custom GPTs — everything in one Plus-grade assistant.</p>
              {activeGpt && <p className="mx-auto mt-3 w-fit rounded-full border border-violet-500/40 bg-violet-500/10 px-4 py-1.5 text-xs text-violet-200">{activeGpt.emoji} Chatting as {activeGpt.name}</p>}
              <div className="mt-7 grid gap-2.5 text-left sm:grid-cols-2">
                {SUGGESTIONS.map((s, i) => (
                  <button key={i} onClick={() => send(s.prompt)} className="group flex items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.02] p-4 text-left transition hover:border-violet-500/40 hover:bg-violet-500/[0.06]">
                    <span className="rounded-xl bg-white/5 p-2 text-violet-300 group-hover:bg-violet-500/20"><s.icon size={17} /></span>
                    <span><span className="block text-sm font-bold">{s.title}</span><span className="mt-0.5 line-clamp-2 block text-xs text-zinc-500">{s.prompt}</span></span>
                  </button>
                ))}
              </div>
              <div className="mt-5 flex flex-wrap justify-center gap-2 text-xs">
                {["/image a cozy cabin in snow", "Summarise this like I'm 5", "Debug my React code", "Plan a 3-day Goa trip"].map((p) => (
                  <button key={p} onClick={() => send(p)} className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-zinc-400 hover:border-white/25 hover:text-white">{p}</button>
                ))}
              </div>
            </div>
          ) : (
            <div className="mx-auto max-w-3xl px-4 pb-48 pt-6 md:px-6">
              {msgs.map((m) => (
                <div key={m.id} className={`group mb-6 flex gap-3 ${m.role === "user" ? "justify-end" : ""}`}>
                  {m.role === "assistant" && (
                    <div className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 text-sm font-black shadow-lg shadow-violet-500/25">K</div>
                  )}
                  <div className={`min-w-0 max-w-[92%] md:max-w-[85%] ${m.role === "user" ? "rounded-2xl rounded-br-md bg-gradient-to-br from-violet-600/90 to-fuchsia-600/80 px-4 py-2.5" : "w-full"}`}>
                    {m.attachments && m.attachments.length > 0 && (
                      <div className="mb-2 flex flex-wrap gap-2">
                        {m.attachments.map((a, i) => (
                          <div key={i} className="overflow-hidden rounded-xl border border-white/15">
                            {a.preview ? (
                              // eslint-disable-next-line @next/next/no-img-element
                              <img src={a.preview} alt={a.name} className="h-28 w-auto object-cover" />
                            ) : (
                              <div className="flex items-center gap-2 bg-white/10 px-3 py-2 text-xs"><FileText size={14} />{a.name}</div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                    {m.role === "user" ? (
                      <div className="whitespace-pre-wrap text-[15px]">{m.content}</div>
                    ) : (
                      <>
                        {m.reasoning && (
                          <details className="mb-2 rounded-xl border border-cyan-400/20 bg-cyan-400/[0.05] px-3 py-2 text-xs text-cyan-100/80">
                            <summary className="cursor-pointer font-bold text-cyan-200">🧠 Reasoning trace</summary>
                            <pre className="mt-1 whitespace-pre-wrap font-mono text-[11px]">{m.reasoning}</pre>
                          </details>
                        )}
                        <Markdown content={m.content} onOpenCanvas={openCanvas} />
                        {m.sources && m.sources.length > 0 && (
                          <div className="mt-3 rounded-2xl border border-white/10 bg-white/[0.02] p-3">
                            <div className="mb-1.5 flex items-center gap-1.5 text-xs font-bold text-zinc-300"><Globe size={12} /> Sources</div>
                            {m.sources.map((s, i) => (
                              <a key={i} href={s.url} target="_blank" rel="noreferrer" className="mb-1 flex items-center gap-1.5 text-xs text-zinc-400 hover:text-violet-200">
                                <ExternalLink size={11} className="shrink-0" /><span className="truncate">{s.title}</span>
                              </a>
                            ))}
                          </div>
                        )}
                        <div className="mt-1.5 flex items-center gap-0.5 opacity-0 transition group-hover:opacity-100">
                          <button onClick={() => { navigator.clipboard.writeText(m.content); showToast("Copied"); }} className="rounded-lg p-1.5 text-zinc-500 hover:bg-white/10 hover:text-white" title="Copy"><Copy size={14} /></button>
                          <button onClick={() => speak(m.content)} className="rounded-lg p-1.5 text-zinc-500 hover:bg-white/10 hover:text-white" title="Read aloud"><Volume2 size={14} /></button>
                          <button onClick={() => feedback(m.id, m.feedback === "up" ? "" : "up")} className={`rounded-lg p-1.5 hover:bg-white/10 ${m.feedback === "up" ? "text-emerald-300" : "text-zinc-500 hover:text-white"}`}><ThumbsUp size={14} /></button>
                          <button onClick={() => feedback(m.id, m.feedback === "down" ? "" : "down")} className={`rounded-lg p-1.5 hover:bg-white/10 ${m.feedback === "down" ? "text-red-300" : "text-zinc-500 hover:text-white"}`}><ThumbsDown size={14} /></button>
                          <button onClick={regenerate} className="rounded-lg p-1.5 text-zinc-500 hover:bg-white/10 hover:text-white" title="Regenerate"><RotateCcw size={14} /></button>
                          {extractHtmlBlocks(m.content).some((b) => b.lang === "html") && (
                            <button onClick={() => { const h = extractHtmlBlocks(m.content).find((b) => b.lang === "html"); if (h) openCanvas(h.code, "html"); }} className="ml-1 flex items-center gap-1 rounded-lg bg-violet-500/20 px-2 py-1 text-[11px] font-bold text-violet-200"><Code2 size={12} /> Canvas</button>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                </div>
              ))}
              {(loading || streamText) && (
                <div className="mb-6 flex gap-3">
                  <div className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 text-sm font-black">K</div>
                  <div className="min-w-0 flex-1 rounded-2xl border border-white/10 bg-white/[0.02] p-4">
                    {streamText && streamText.startsWith("KDJ is thinking") ? (
                      <div className="flex items-center gap-2 text-sm text-zinc-400"><Loader2 size={15} className="animate-spin text-violet-300" />{streamText}<span className="flex gap-1"><span className="h-1.5 w-1.5 animate-bounce rounded-full bg-violet-400" /><span className="h-1.5 w-1.5 animate-bounce rounded-full bg-fuchsia-400 [animation-delay:150ms]" /><span className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-400 [animation-delay:300ms]" /></span></div>
                    ) : streamText ? (
                      <div className="opacity-80"><Markdown content={streamText + "▍"} onOpenCanvas={openCanvas} /></div>
                    ) : (
                      <div className="flex items-center gap-2 text-sm text-zinc-400"><Loader2 size={15} className="animate-spin text-violet-300" /> KDJ is thinking…</div>
                    )}
                  </div>
                </div>
              )}
              {followups.length > 0 && !loading && (
                <div className="mb-8 flex flex-wrap gap-2">
                  <span className="w-full text-[11px] uppercase tracking-widest text-zinc-600">Suggested follow-ups</span>
                  {followups.map((f, i) => (
                    <button key={i} onClick={() => send(f)} className="rounded-full border border-violet-500/30 bg-violet-500/10 px-3.5 py-1.5 text-[13px] text-violet-100 transition hover:bg-violet-500/20">✨ {f}</button>
                  ))}
                </div>
              )}
              <div ref={bottomRef} />
            </div>
          )}
        </div>

        {/* composer */}
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#0a0a10] via-[#0a0a10]/95 to-transparent px-3 pb-3 pt-8 md:px-6 md:pb-5">
          <div className={`mx-auto ${canvasOpen ? "max-w-2xl" : "max-w-3xl"}`}>
            {attachments.length > 0 && (
              <div className="mb-2 flex flex-wrap gap-2">
                {attachments.map((a, i) => (
                  <div key={i} className="relative overflow-hidden rounded-xl border border-violet-500/30 bg-[#15151d]">
                    {a.preview ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={a.preview} alt={a.name} className="h-16 w-auto object-cover" />
                    ) : (
                      <div className="flex items-center gap-2 px-3 py-2 text-xs"><FileText size={14} className="text-violet-300" /><span className="max-w-[140px] truncate">{a.name}</span></div>
                    )}
                    <button onClick={() => setAttachments((p) => p.filter((_, x) => x !== i))} className="absolute right-1 top-1 rounded-full bg-black/70 p-0.5"><X size={12} /></button>
                  </div>
                ))}
              </div>
            )}
            <div className={`rounded-3xl border bg-[#15151d]/95 shadow-2xl backdrop-blur transition ${loading ? "border-violet-500/30" : "border-white/12 focus-within:border-violet-500/50"}`}>
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => { setInput(e.target.value); e.target.style.height = "auto"; e.target.style.height = Math.min(200, e.target.scrollHeight) + "px"; }}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && enterToSend) { e.preventDefault(); send(); } if ((e.metaKey || e.ctrlKey) && e.key === "k") { e.preventDefault(); newChat(); } }}
                rows={1}
                placeholder={activeGpt ? `Ask ${activeGpt.name}…` : imageMode || model === "kdj-image" ? "Describe the image to generate… 🎨" : "Message KDJ… (Enter to send, Shift+Enter for new line)"}
                className="max-h-[200px] w-full resize-none bg-transparent px-5 pb-1 pt-4 text-[15px] outline-none placeholder:text-zinc-600"
              />
              <div className="flex items-center gap-1 px-3 pb-3">
                <button onClick={() => fileRef.current?.click()} className="rounded-xl p-2 text-zinc-400 hover:bg-white/10 hover:text-white" title="Attach files / images"><Paperclip size={17} /></button>
                <input ref={fileRef} type="file" multiple accept="image/*,.pdf,.txt,.md,.csv,.json,.js,.ts,.tsx,.py,.html,.css" className="hidden" onChange={(e) => { handleFiles(e.target.files); e.target.value = ""; }} />
                <button onClick={toggleMic} className={`rounded-xl p-2 ${listening ? "bg-red-500/20 text-red-300" : "text-zinc-400 hover:bg-white/10 hover:text-white"}`} title="Voice input">{listening ? <Square size={16} /> : <Mic size={17} />}</button>
                <button onClick={() => setWebSearch(!webSearch)} className={`flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-xs font-bold ${webSearch ? "bg-emerald-500/15 text-emerald-200" : "text-zinc-500 hover:bg-white/10"}`} title="Web search"><Globe size={15} /><span className="hidden sm:inline">{webSearch ? "Web on" : "Web off"}</span></button>
                <button onClick={() => { const v = !(imageMode || model === "kdj-image"); setImageMode(v); if (v) setModel("kdj-image"); else if (model === "kdj-image") setModel("kdj-4o"); }} className={`flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-xs font-bold ${(imageMode || model === "kdj-image") ? "bg-orange-500/15 text-orange-200" : "text-zinc-500 hover:bg-white/10"}`} title="Image mode"><ImageIcon size={15} /><span className="hidden sm:inline">Image</span></button>
                <button onClick={() => setShowImgStudio(true)} className="hidden rounded-xl p-2 text-zinc-400 hover:bg-white/10 hover:text-white sm:block" title="Image Studio"><Wand2 size={16} /></button>
                <div className="ml-auto flex items-center gap-1.5">
                  {input.trim() && <span className="hidden text-[11px] text-zinc-600 md:block"><CornerDownLeft size={11} className="inline" /> send</span>}
                  <button onClick={() => send()} disabled={loading || (!input.trim() && attachments.length === 0)} className="grid h-9 w-9 place-items-center rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 shadow-lg shadow-violet-500/30 transition hover:brightness-110 disabled:opacity-30">
                    {loading ? <Loader2 size={17} className="animate-spin" /> : <Send size={16} />}
                  </button>
                </div>
              </div>
            </div>
            <p className="mt-2 text-center text-[11px] text-zinc-600">KDJ can make mistakes — verify important info · <span className="text-zinc-500">⌘K new chat</span> · Files, voice, web & images built-in</p>
          </div>
        </div>
      </main>

      {/* CANVAS */}
      {canvasOpen && (
        <section className="hidden w-[440px] shrink-0 flex-col border-l border-white/10 bg-[#0e0e15] lg:flex">
          <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
            <Code2 size={16} className="text-violet-300" />
            <span className="text-sm font-bold">KDJ Canvas</span>
            <span className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[10px] uppercase text-zinc-400">{canvasLang}</span>
            <div className="ml-auto flex gap-1">
              <button onClick={() => setCanvasTab("preview")} className={`rounded-lg px-2.5 py-1 text-xs font-bold ${canvasTab === "preview" ? "bg-white/10 text-white" : "text-zinc-500"}`}>Preview</button>
              <button onClick={() => setCanvasTab("code")} className={`rounded-lg px-2.5 py-1 text-xs font-bold ${canvasTab === "code" ? "bg-white/10 text-white" : "text-zinc-500"}`}>Code</button>
              <button onClick={() => { navigator.clipboard.writeText(canvasCode); showToast("Canvas copied"); }} className="rounded-lg p-1.5 text-zinc-400 hover:bg-white/10"><Copy size={14} /></button>
              <button onClick={() => setCanvasOpen(false)} className="rounded-lg p-1.5 text-zinc-400 hover:bg-white/10"><X size={15} /></button>
            </div>
          </div>
          <div className="flex-1 overflow-hidden">
            {canvasTab === "preview" ? (
              canvasLang === "html" ? (
                <iframe title="canvas-preview" srcDoc={canvasCode} className="h-full w-full bg-white" sandbox="allow-scripts" />
              ) : (
                <pre className="h-full overflow-auto p-4 font-mono text-xs leading-relaxed text-zinc-200">{canvasCode || "// Code will appear here — ask KDJ to write something, then open it in Canvas."}</pre>
              )
            ) : (
              <textarea value={canvasCode} onChange={(e) => setCanvasCode(e.target.value)} spellCheck={false} className="h-full w-full resize-none bg-[#0b0b12] p-4 font-mono text-xs leading-relaxed outline-none" placeholder="// Ask KDJ for code, then edit it live here…" />
            )}
          </div>
          {!canvasCode && (
            <div className="border-t border-white/10 p-4 text-center text-xs text-zinc-500">Ask KDJ to <button className="text-violet-300 underline" onClick={() => { setCanvasOpen(false); send("Write a stunning HTML landing page for my AI startup"); }}>“build a landing page”</button> and it will appear here live.</div>
          )}
        </section>
      )}

      {/* IMAGE STUDIO */}
      {showImgStudio && (
        <div className="fixed inset-0 z-[70] grid place-items-center bg-black/70 p-4 backdrop-blur-sm" onClick={() => setShowImgStudio(false)}>
          <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-[#14141c] p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2"><Wand2 size={18} className="text-orange-300" /><h2 className="text-lg font-extrabold">KDJ Image Studio</h2><button onClick={() => setShowImgStudio(false)} className="ml-auto rounded-lg p-1.5 hover:bg-white/10"><X size={16} /></button></div>
            <p className="mt-1 text-xs text-zinc-500">Powered by KDJ Image · 1024px · free, unlimited</p>
            <textarea value={imgPrompt} onChange={(e) => setImgPrompt(e.target.value)} rows={3} placeholder="A cozy cabin in snowy mountains, warm lights, cinematic…" className="mt-4 w-full resize-none rounded-2xl border border-white/10 bg-white/[0.04] p-3.5 text-sm outline-none focus:border-orange-400/50" />
            <div className="mt-3 flex flex-wrap gap-2">
              {(["vivid", "photoreal", "anime", "cyberpunk", "oil"] as const).map((s) => (
                <button key={s} onClick={() => setImgStyle(s)} className={`rounded-full px-3.5 py-1.5 text-xs font-bold capitalize ${imgStyle === s ? "bg-orange-400 text-black" : "bg-white/5 text-zinc-300 hover:bg-white/10"}`}>{s}</button>
              ))}
            </div>
            <button onClick={doImageGen} disabled={imgLoading || !imgPrompt.trim()} className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-orange-400 to-pink-500 py-3 text-sm font-bold text-black disabled:opacity-40">
              {imgLoading ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />} Generate image
            </button>
            {genImages.length > 0 && (
              <div className="mt-4 grid max-h-48 grid-cols-4 gap-2 overflow-y-auto">
                {genImages.slice(0, 8).map((im) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img key={im.id} src={im.url} alt={im.prompt} className="aspect-square rounded-xl border border-white/10 object-cover" loading="lazy" />
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* GPT BUILDER */}
      {showGptBuilder && (
        <div className="fixed inset-0 z-[70] grid place-items-center bg-black/70 p-4 backdrop-blur-sm" onClick={() => setShowGptBuilder(false)}>
          <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-[#14141c] p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2"><Bot size={18} className="text-violet-300" /><h2 className="text-lg font-extrabold">Build a custom GPT</h2><button onClick={() => setShowGptBuilder(false)} className="ml-auto rounded-lg p-1.5 hover:bg-white/10"><X size={16} /></button></div>
            <div className="mt-4 space-y-3">
              <div className="flex gap-2">
                <input value={newGpt.emoji} onChange={(e) => setNewGpt({ ...newGpt, emoji: e.target.value })} className="w-14 rounded-2xl border border-white/10 bg-white/[0.04] p-3 text-center text-xl outline-none" />
                <input value={newGpt.name} onChange={(e) => setNewGpt({ ...newGpt, name: e.target.value })} placeholder="Name — e.g. Code Mentor" className="flex-1 rounded-2xl border border-white/10 bg-white/[0.04] p-3 text-sm outline-none focus:border-violet-500/50" />
              </div>
              <input value={newGpt.description} onChange={(e) => setNewGpt({ ...newGpt, description: e.target.value })} placeholder="One-line description" className="w-full rounded-2xl border border-white/10 bg-white/[0.04] p-3 text-sm outline-none focus:border-violet-500/50" />
              <textarea value={newGpt.instructions} onChange={(e) => setNewGpt({ ...newGpt, instructions: e.target.value })} rows={4} placeholder="Instructions — how should this GPT behave? e.g. 'You are a senior Python coach. Always give runnable code…'" className="w-full resize-none rounded-2xl border border-white/10 bg-white/[0.04] p-3 text-sm outline-none focus:border-violet-500/50" />
              <button onClick={doCreateGpt} className="w-full rounded-2xl bg-gradient-to-r from-violet-500 to-fuchsia-500 py-3 text-sm font-bold">Create GPT</button>
            </div>
          </div>
        </div>
      )}

      {/* SETTINGS */}
      {showSettings && (
        <div className="fixed inset-0 z-[70] grid place-items-center bg-black/70 p-4 backdrop-blur-sm" onClick={() => setShowSettings(false)}>
          <div className="w-full max-w-md rounded-3xl border border-white/10 bg-[#14141c] p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2"><Settings size={18} /><h2 className="text-lg font-extrabold">Settings</h2><button onClick={() => setShowSettings(false)} className="ml-auto rounded-lg p-1.5 hover:bg-white/10"><X size={16} /></button></div>
            <div className="mt-4 space-y-3 text-sm">
              {[
                { label: "Auto read responses aloud", desc: "KDJ speaks every answer", val: autoTTS, set: setAutoTTS },
                { label: "Enter to send", desc: "Shift+Enter for new line", val: enterToSend, set: setEnterToSend },
                { label: "Web search by default", desc: "Live sources in answers", val: webSearch, set: setWebSearch },
              ].map((r, i) => (
                <div key={i} className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.02] px-4 py-3">
                  <div><div className="font-bold">{r.label}</div><div className="text-xs text-zinc-500">{r.desc}</div></div>
                  <button onClick={() => r.set(!r.val)} className={`h-6 w-11 rounded-full p-0.5 transition ${r.val ? "bg-emerald-500" : "bg-white/10"}`}><span className={`block h-5 w-5 rounded-full bg-white transition ${r.val ? "ml-auto" : ""}`} /></button>
                </div>
              ))}
              <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/[0.04] px-4 py-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold">Database · KDJ cluster</div>
                    <div className="text-xs text-emerald-200/70">PostgreSQL · Drizzle ORM · live</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-black text-emerald-300">{dbStats?.totalTables ?? "…"}</div>
                    <div className="text-[10px] uppercase tracking-widest text-zinc-500">tables</div>
                  </div>
                </div>
                <div className="mt-2 max-h-28 overflow-y-auto rounded-xl border border-white/5 bg-black/20 p-2 font-mono text-[10px] leading-relaxed text-zinc-400">
                  {dbStats ? dbStats.tables.map((t) => (
                    <div key={t.table} className="flex justify-between"><span>{t.table}</span><span className="text-zinc-600">{t.rows}r</span></div>
                  )) : "Loading tables…"}
                </div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/[0.02] px-4 py-3">
                <div className="font-bold">Data</div>
                <div className="mt-2 flex gap-2">
                  <button onClick={() => { window.speechSynthesis?.cancel(); showToast("Voice stopped"); }} className="flex items-center gap-1 rounded-xl bg-white/10 px-3 py-2 text-xs font-bold"><VolumeX size={13} /> Stop voice</button>
                  <button onClick={() => { if (confirm("Delete ALL chats?")) { convs.forEach((c) => fetch(`/api/conversations/${c.id}`, { method: "DELETE" })); setTimeout(() => { loadConvs(); newChat(); }, 600); } }} className="flex items-center gap-1 rounded-xl bg-red-500/15 px-3 py-2 text-xs font-bold text-red-200"><Trash2 size={13} /> Clear all</button>
                </div>
              </div>
              <p className="text-center text-[11px] text-zinc-600">KDJ Plus · v4o · Built with memory, voice, vision & image studio</p>
            </div>
          </div>
        </div>
      )}

      {/* VOICE MODE */}
      {voiceOpen && (
        <div className="fixed inset-0 z-[80] flex flex-col items-center justify-center bg-[#08080d]/97 p-6 backdrop-blur-xl">
          <button onClick={() => { setVoiceOpen(false); setListening(false); (recogRef.current as { stop?: () => void } | null)?.stop?.(); }} className="absolute right-5 top-5 rounded-full bg-white/10 p-2.5"><X size={18} /></button>
          <div className="relative">
            <div className={`grid h-32 w-32 place-items-center rounded-full bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-400 text-5xl font-black shadow-2xl ${listening ? "animate-pulse" : ""}`}>K</div>
            {listening && <span className="absolute inset-0 animate-ping rounded-full bg-violet-500/20" />}
          </div>
          <h2 className="mt-6 text-2xl font-black">{listening ? "Listening…" : "Voice mode"}</h2>
          <p className="mt-1 max-w-sm text-center text-sm text-zinc-400">{voiceTranscript || "Tap the orb and talk — KDJ will answer in chat."}</p>
          <div className="mt-6 flex gap-3">
            {!listening ? (
              <button onClick={() => {
                try {
                  const SR = (window as unknown as { webkitSpeechRecognition?: new () => unknown }).webkitSpeechRecognition || (window as unknown as { SpeechRecognition?: new () => unknown }).SpeechRecognition;
                  if (!SR) { showToast("Voice needs Chrome"); return; }
                  const recog = new (SR as new () => { lang: string; onresult: ((e: { results: { [i: number]: { [j: number]: { transcript: string } } } }) => void) | null; onend: (() => void) | null; start: () => void; stop: () => void })();
                  recog.lang = "en-US";
                  recogRef.current = recog;
                  recog.onresult = (e) => { const t = e.results[0]?.[0]?.transcript || ""; setVoiceTranscript(t); };
                  recog.onend = () => {
                    setListening(false);
                    setVoiceTranscript((cur) => { if (cur.trim()) setTimeout(() => voiceAsk(cur), 400); return cur; });
                  };
                  recog.start();
                  setListening(true);
                } catch { showToast("Mic unavailable"); }
              }} className="flex items-center gap-2 rounded-full bg-white px-7 py-3.5 font-bold text-black"><Mic size={17} /> Tap to talk</button>
            ) : (
              <button onClick={() => { (recogRef.current as { stop?: () => void } | null)?.stop?.(); setListening(false); }} className="flex items-center gap-2 rounded-full bg-red-500 px-7 py-3.5 font-bold"><MicOff size={17} /> Stop</button>
            )}
            {voiceTranscript.trim() && !listening && (
              <button onClick={() => voiceAsk(voiceTranscript)} className="flex items-center gap-2 rounded-full bg-violet-500 px-7 py-3.5 font-bold"><Send size={16} /> Ask KDJ</button>
            )}
          </div>
          <div className="mt-6 flex flex-wrap justify-center gap-2 text-xs">
            {["Tell me a fun fact", "Motivate me", "Explain black holes simply"].map((p) => (
              <button key={p} onClick={() => voiceAsk(p)} className="rounded-full border border-white/15 px-4 py-2 text-zinc-300 hover:bg-white/10">{p}</button>
            ))}
          </div>
        </div>
      )}

      {/* mobile sidebar drawer */}
      {!sidebarOpen && (
        <button onClick={() => setSidebarOpen(true)} className="fixed left-3 top-[70px] z-40 rounded-xl border border-white/10 bg-[#15151d] p-2 shadow-xl md:hidden"><Menu size={16} /></button>
      )}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black/60 md:hidden" onClick={() => setSidebarOpen(false)}>
          <div className="h-full w-[280px] overflow-y-auto bg-[#111116] p-4" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between">
              <span className="font-extrabold">KDJ PLUS</span>
              <button onClick={() => setSidebarOpen(false)}><X size={18} /></button>
            </div>
            <button onClick={() => { newChat(); setSidebarOpen(false); }} className="flex w-full items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-2.5 text-sm font-semibold"><Plus size={16} /> New chat</button>
            <div className="mt-3 space-y-1">
              {filtered.slice(0, 30).map((c) => (
                <button key={c.id} onClick={() => { setActiveId(c.id); setSidebarOpen(false); }} className={`block w-full truncate rounded-lg px-3 py-2 text-left text-sm ${activeId === c.id ? "bg-white/10" : "hover:bg-white/5"}`}>{c.title}</button>
              ))}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
              <button onClick={() => { setView("gpts"); setSidebarOpen(false); }} className="rounded-xl bg-white/5 p-3 font-bold">🤖 GPTs</button>
              <button onClick={() => { setShowImgStudio(true); }} className="rounded-xl bg-white/5 p-3 font-bold">🎨 Images</button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className="fixed bottom-24 left-1/2 z-[90] -translate-x-1/2 rounded-full border border-white/15 bg-[#1b1b24] px-4 py-2 text-xs font-semibold shadow-2xl">{toast}</div>
      )}

      <style jsx global>{`
        .kdj-md pre { background: transparent !important; }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,.12); border-radius: 99px; }
        ::-webkit-scrollbar-track { background: transparent; }
      `}</style>
    </div>
  );
}
