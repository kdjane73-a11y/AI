INSERT INTO kdj_model_catalog (slug, name, description, tier, capabilities) VALUES
 ('kdj-4o','KDJ-4o','Smartest all-round · chat, code, files','plus','["chat","vision","files","web","canvas"]'),
 ('kdj-o1','KDJ-o1','Deep reasoning · math, logic, planning','plus','["reasoning","code","web"]'),
 ('kdj-mini','KDJ-mini','Lightning fast everyday answers','free','["chat","web"]'),
 ('kdj-vision','KDJ Vision','Image analysis · screenshots, diagrams','plus','["vision","files"]'),
 ('kdj-canvas','KDJ Canvas','Live code editing + preview','plus','["code","canvas"]'),
 ('kdj-image','KDJ Image','Unlimited art & poster generation','free','["image"]');

INSERT INTO kdj_plan_tiers (slug, name, price_monthly, features) VALUES
 ('free','KDJ Free',0,'["KDJ-mini","KDJ Image","Web browsing","10 GPTs"]'),
 ('plus','KDJ Plus',20,'["All models","Unlimited GPTs","Voice mode","Canvas","Memory","Priority speed"]'),
 ('pro','KDJ Pro',200,'["Everything in Plus","API access","Team workspace","1M tokens/day"]');

INSERT INTO kdj_app_settings (key, value) VALUES
 ('default_model','"kdj-4o"'),
 ('site_name','"KDJ PLUS"'),
 ('db_tables','100'),
 ('version','"4o"');
